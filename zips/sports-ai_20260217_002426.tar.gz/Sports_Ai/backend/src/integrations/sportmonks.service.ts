import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import axios, { AxiosInstance } from 'axios';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class SportmonksService implements OnModuleInit {
  private readonly logger = new Logger(SportmonksService.name);
  private client!: AxiosInstance;
  private apiKey: string;
  private readonly baseUrl = 'https://api.sportmonks.com/v3';

  constructor(private configService: ConfigService) {
    this.apiKey = this.configService.get<string>('SPORTMONKS_API_KEY') || 'YOUR_API_KEY';
  }

  onModuleInit() {
    this.client = axios.create({
      baseURL: this.baseUrl,
      params: {
        api_token: this.apiKey,
      },
    });
  }

  async getFootballLeagues() {
    try {
      const response = await this.client.get('/core/leagues');
      return response.data.data;
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      this.logger.error(`Failed to fetch football leagues: ${msg}`);
      throw error;
    }
  }

  async getFootballFixtures(params: any) {
    try {
      const response = await this.client.get('/football/fixtures', { params });
      return response.data.data;
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      this.logger.error(`Failed to fetch football fixtures: ${msg}`);
      throw error;
    }
  }

  async getCricketLeagues() {
    try {
      const response = await this.client.get('/cricket/leagues');
      return response.data.data;
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      this.logger.error(`Failed to fetch cricket leagues: ${msg}`);
      throw error;
    }
  }
}
