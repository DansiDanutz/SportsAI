export { TeamDetailPage } from './TeamDetailPage';
