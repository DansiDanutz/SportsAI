export { TermsPage } from './TermsPage';
export { PrivacyPage } from './PrivacyPage';
