export { EventDetailPage } from './EventDetailPage';
