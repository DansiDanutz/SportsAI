export { FavoritesPage } from './FavoritesPage';
